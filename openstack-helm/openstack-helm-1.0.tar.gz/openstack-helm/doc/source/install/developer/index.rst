Development
===========

Contents:

.. toctree::
   :maxdepth: 2

   requirements-and-host-config
   kubernetes-and-common-setup
   deploy-with-nfs
   deploy-with-ceph
   exercise-the-cloud
   cleaning-deployment
