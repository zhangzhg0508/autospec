Puppet::Type.newtype(:openstack_config) do

end
