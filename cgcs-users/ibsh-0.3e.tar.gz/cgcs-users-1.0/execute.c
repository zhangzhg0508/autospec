/*
  Created: 03.19.05 11:34:57 by Attila Nagyidai

  $Id: C\040Console.c,v 1.1.2.1 2003/08/13 00:38:46 neum Exp $

  This file is part of IBSH (Iron Bars Shell) , a restricted Unix shell
  Copyright (C) 2005  Attila Nagyidai

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Author: Attila Nagyidai
  Email: na@ent.hu

  Co-Author: Shy
  Email: shy@cpan.org

  Co-Author: Witzy
  Email: stazzz@altern.org
  
  URL: http://ibsh.sourceforge.net
  IRC: irc.freenode.net #ibsh
  RSS, Statistics, etc: http://sourceforge.net/projects/ibsh/

*/

/* Header files */
#include "ibsh.h"

/* Counts the spaces in the command */
int nbspace(const char *command)
{
int i=0;
int nbspace=0;

while(command[i] != '\0'){
	if(command[i] == ' ')
		nbspace++;
	i++;
}

return nbspace;
}

/* Shy's improved and secured version of hhsystem, originally taken from */
/* the book: Linux Unix Systemprogramming by Helmut Herold. */
int  hhsystem(const char *user_command)   /*--- Version ohne Signalbehandlung ---*/
{
   pid_t   pid;
   int     status;
   int i=0;
   int find = 0;

   char *field;

   char path[STRING_SIZE];

   char *current_path;
   char *fieldspath;
   char *params[nbspace(user_command) + 1];

   DIR *currentdir;
   struct dirent *pdirent;

   if (user_command == NULL)
      return(1);   /* In Unix ist immer Kommandoprozessor vorhanden */

   if ( (pid=fork()) < 0)
      status = -1;

   else if (pid == 0) {
	 /* Split the command */
	field = strtok((char *)user_command," ");
	while(field != NULL){
#ifdef DEBUG
		printf("CHAMPS %s\n",field);
#endif
		params[i] = malloc(strlen(field) + 1);
		bzero(params[i],strlen(field)+1);
		strncpy(params[i],field,strlen(field));
		i++;
		field = strtok(NULL," ");

	}
	/* Put NULL at the end for execve */
	params[i] = NULL;

	/* Get PATH */
	current_path = getenv("PATH");

#ifdef DEBUG
	printf("PATH %s %s\n",current_path,loggedin.udir);
#endif

	/* Parse the PATH if the command is in the home dir it's skip !! */
        fieldspath = strtok((char *)current_path,":");
		while((fieldspath != NULL) && find != 1){
#ifdef DEBUG
			printf("FIELD PATH %s\n",fieldspath);
#endif
			if(!strstr(fieldspath,loggedin.udir)){
		  		if((currentdir = opendir(fieldspath)) != NULL){

					while(((pdirent = readdir(currentdir)) != NULL) && find != 1){
						if(!strncmp(pdirent->d_name,params[0],sizeof(params[0]))){
#ifdef DEBUG
						printf("TROUVE %s!!!!\n",pdirent->d_name);
#endif
						find = 1;

					}
				}
			}
				closedir(currentdir);
			}
			if(find == 0)
				fieldspath = strtok(NULL,":");
			
		}

	/* Contruct the real command with the good path */
	if(find == 1 && ((strlen(fieldspath)+strlen(params[0])+1) < sizeof(path))){
		bzero(path,sizeof(path));
		snprintf(path,sizeof(path)-1,"%s/%s",fieldspath,params[0]);
		path[sizeof(path)-1] = '\0';

#ifdef DEBUG
    printf("PATH FINAL %s %d ok!\n",path,strlen(path));
		printf("PARAMS[0] %s\n",params[0]);
		printf("PARAMS[1] %s\n",params[1]);
#endif
		execve(path,params,environ);
	}
	/* The command is in the home dir :( bad for you guys !! */
	else{
		status = -1;
	}
	_exit(127);

   } else
      while (waitpid(pid, &status, 0) < 0)
         if (errno != EINTR) {
            status = -1;
            break;
         }

   return(status);
}
