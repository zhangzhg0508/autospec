/*
  Created: 03.19.05 11:34:57 by Attila Nagyidai

  $Id: C\040Console.c,v 1.1.2.1 2003/08/13 00:38:46 neum Exp $

  This file is part of IBSH (Iron Bars Shell) , a restricted Unix shell
  Copyright (C) 2005  Attila Nagyidai

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Author: Attila Nagyidai
  Email: na@ent.hu

  Co-Author: Shy
  Email: shy@cpan.org

  Co-Author: Witzy
  Email: stazzz@altern.org
  
  URL: http://ibsh.sourceforge.net
  IRC: irc.freenode.net #ibsh
  RSS, Statistics, etc: http://sourceforge.net/projects/ibsh/

*/

/* Header files */
#include "ibsh.h"

/* If the command is not ok, there is a possible hack attempt. */
/* Can also be a typo, but we're not taking any chances. v0.2a */
void log_attempt( const char *username )
{
  char logmsg[STRING_SIZE];

  snprintf(logmsg, 50, "Possible hack attempt by %s.", username);
  
  OPENLOG;
  syslog(LOG_WARNING, "%s", logmsg);
  CLOSELOG;
}
