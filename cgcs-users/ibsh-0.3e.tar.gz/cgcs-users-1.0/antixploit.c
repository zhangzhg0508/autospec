/*
  Created: 03.19.05 11:34:57 by Attila Nagyidai

  $Id: C\040Console.c,v 1.1.2.1 2003/08/13 00:38:46 neum Exp $

  This file is part of IBSH (Iron Bars Shell) , a restricted Unix shell
  Copyright (C) 2005  Attila Nagyidai

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Author: Attila Nagyidai
  Email: na@ent.hu

  Co-Author: Shy
  Email: shy@cpan.org

  Co-Author: Witzy
  Email: stazzz@altern.org
  
  URL: http://ibsh.sourceforge.net
  IRC: irc.freenode.net #ibsh
  RSS, Statistics, etc: http://sourceforge.net/projects/ibsh/

*/

/* Header files */
#include "ibsh.h"


void lshift( char *line )
{
  int i = 0;
  
  for (i=0; i<strlen(line) - 1; i++) {
      line[i] = line[i+1];
  }
}


/* Checks if a part of the command line contains */
/* a file in the jail, that is a source code. */
/* Source codes must not be compiled, interpreted, */
/* or otherwise used. */
/* abspath is loggedin.udir, if the token is a path. */
/* otherwise abspath is realpath. */
int antixploit( const char *abspath, char *token )
{
  char jailfile[STRING_SIZE], line[LINE_SIZE], temp[BUFFER_SIZE];
  struct stat info;
  FILE *fp;
  int retval = 0;

  
  snprintf(jailfile, STRING_SIZE, "%s/%s/%s", loggedin.udir, abspath, token);
#ifdef DEBUG
  printf("jailfile: %s\n", jailfile);
#endif
  if ( (lstat(jailfile, &info)) == -1 ) {
      // this is not a file
      return 0;
  }

  fp = fopen(jailfile, "rb");
  if ( fp == NULL ) {
      // if i cant open it, gcc cant open it
      return 0;
  }

  fgets(line, LINE_SIZE, fp);
  while ( line[0] != '\0' ) {
#ifdef DEBUG
      printf("Line: %s\n", line);
#endif
      // c, c++
      if ( (strncmp(line, C_CODE, strlen(C_CODE) - 1)) == 0 ) {
          retval = 1;
          break;
      }
      // perl, sh, python
      if ( (strncmp(line, SHELL_CODE, strlen(SHELL_CODE) - 1)) == 0 ) {
          retval = 1;
          break;
      }
      // python
      if ( (strncmp(line, PYTHON_CODE, strlen(PYTHON_CODE) - 1)) == 0 ) {
          retval = 1;
          break;
      }
      // ada
      if ( (strncmp(line, ADA_CODE, strlen(ADA_CODE) - 1)) == 0 ) {
          retval = 1;
          break;
      }
      // eiffel
      if ( (strncmp(line, EIFFEL_CODE, strlen(EIFFEL_CODE) - 1)) == 0 ) {
          retval = 1;
          break;
      }
      // lisp
      if ( (strncmp(line, LISP_CODE, strlen(LISP_CODE) - 1)) == 0 ) {
          retval = 1;
          break;
      }
      // elf
      lshift(line);
      if ( (strncmp(line, ELF_CODE, strlen(ELF_CODE) - 1)) == 0 ) {
          retval = 1;
          break;
      }
      bzero(line, LINE_SIZE);
      fgets(line, LINE_SIZE, fp);
  }
  fclose(fp);
#ifdef DEBUG
  printf("retval: %d\n", retval);
#endif
  return retval;
}

