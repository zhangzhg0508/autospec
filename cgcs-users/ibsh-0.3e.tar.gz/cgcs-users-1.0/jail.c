/*
  Created: 03.19.05 11:34:57 by Attila Nagyidai

  $Id: C\040Console.c,v 1.1.2.1 2003/08/13 00:38:46 neum Exp $

  This file is part of IBSH (Iron Bars Shell) , a restricted Unix shell
  Copyright (C) 2005  Attila Nagyidai

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Author: Attila Nagyidai
  Email: na@ent.hu

  Co-Author: Shy
  Email: shy@cpan.org

  Co-Author: Witzy
  Email: stazzz@altern.org
  
  URL: http://ibsh.sourceforge.net
  IRC: irc.freenode.net #ibsh
  RSS, Statistics, etc: http://sourceforge.net/projects/ibsh/

*/

/* Header files */
#include "ibsh.h"



/* Remove the path of the Jail root dir from the displayed paths! */
/* Return the jail path from the absolute path. */
/* Copy characters from absolute path to jail path, starting, where the */
/* jail root ends. */
void GetPositionInJail( const char *abspath, const char *rootdir, char *relpath )
{
  int i = 0;
  int j = 0;
  
  bzero(relpath, strlen(relpath));
  for (i = strlen(rootdir); i < strlen(abspath); i++) {
      relpath[j] = abspath[i];
      j++;
  }
  relpath[j] = '\0';
}

/* Take 3 characters from left off a string. */
/* It practically removes one ../ . */
void LTrim3( const char *base, char *result )
{
  int i = 0;
  int j = 0;

  bzero(result, strlen(result));
  for (i = 3; i < strlen(base); i++) {
      result[j] = base[i];
      j++;
  }
  result[j] = '\0';
}

/* Remove one subdirectory from the path in the argument. */
/* In case the user uses ../ 's in his command. */
/* Technical Description: */
/* Variables: string pointer for the strtok function, and an */
/* integer to stop the removing. */
/* Disassemble the path by the slashes. And glue the required parts */
/* together. Number of required parts = number of all parts - 1 . */
void PathMinusOne( const char *basepath, char *evalpath, int slashcount,size_t nevalpath )
{
  char *tok;
  int j = 1;
  
  bzero(evalpath, strlen(evalpath));
  if ( slashcount == 1 ) {
      strncpy(evalpath,"/",nevalpath-1);
      evalpath[nevalpath-1] = '\0';
  }
  else {
      for (tok = strtok((void *) basepath, "/"); tok; tok = strtok(0, "/")) {
          if ( j < slashcount ) {
              strncat(evalpath,tok,nevalpath-strlen(evalpath)-1);
               strncat(evalpath,"/",nevalpath-strlen(evalpath)-1);
          }
          j++;
      }
  }
}
