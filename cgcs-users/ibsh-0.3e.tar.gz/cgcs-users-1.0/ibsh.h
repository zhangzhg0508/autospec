/*
  Created: 03.19.05 11:15:21 by Attila Nagyidai

  $Id: C\040Header.h,v 1.1.2.1 2003/08/13 00:38:46 neum Exp $

  This file is part of IBSH (Iron Bars Shell) , a restricted Unix shell
  Copyright (C) 2005  Attila Nagyidai

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Author: Attila Nagyidai
  Email: na@ent.hu

  Co-Author: Shy
  Email: shy@cpan.org

  URL: http://ibsh.sourceforge.net
  IRC: irc.freenode.net #ibsh
  RSS, Statistics, etc: http://sourceforge.net/projects/ibsh/

*/

#ifndef _IBSH_H
#define _IBSH_H

/* Insert Code here */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <syslog.h>
#include <fcntl.h>
#include <errno.h>
#include <dirent.h>
#include <pwd.h>
#include <grp.h>
#include <limits.h>
#include <glob.h>
#include <signal.h>

#define PAM_SIZE    8
#define LINE_SIZE   80
#define STRING_SIZE 255
#define BUFFER_SIZE 4096
#define PATH_MAX 4096
#define MAX_ITEMS   50
#define COMMANDS_DIR "/etc/ibsh/cmds"
#define COMMANDS_FILE "/etc/ibsh/globals.cmds"
#define EXTENSIONS_DIR "/etc/ibsh/xtns"
#define EXTENSIONS_FILE "/etc/ibsh/globals.xtns"

/* Antixploit */
#define C_CODE  "#include"
#define SHELL_CODE  "#!/"
#define PYTHON_CODE "import"
#define ADA_CODE  "package body"
#define EIFFEL_CODE "feature --"
#define LISP_CODE "(defun"
#define ELF_CODE "ELF"

/* Logging */
#define OPENLOG     openlog("ibsh", LOG_PID, LOG_AUTH)
#define CLOSELOG    closelog()

/* Typedefs, structs, globals */
typedef struct theuser {
    char uname[STRING_SIZE];
    uid_t uid;
    char udir[STRING_SIZE];
    struct passwd *record;
} theuser;

typedef char Strng[STRING_SIZE];

theuser loggedin; /* user info */

//static Strng commands[MAX_ITEMS];  /* permitted commands */
Strng commands[MAX_ITEMS];
Strng extensions[MAX_ITEMS];
/*static Strng extensions[MAX_ITEMS];   permitted extensions */
char real_path[STRING_SIZE];    /* absolute path */
char jail_path[STRING_SIZE];    /* path inside the jail */
char user_command[STRING_SIZE];   /* whatever the user types */
char filtered_command[STRING_SIZE]; /* this one will be executed */
int exitcode;
extern char **environ;


int CommandOK( const char *thecommand, const char *rootdir,
const char *jailpath, char *newcommand );
void LTrim3( const char *base, char *result );
void GetPositionInJail( const char *abspath, const char *rootdir, char *relpath );
int LoadConfig( void );
void myscanf( char *vptr, char *abspath );
int  hhsystem(const char *kdozeile);
void PathMinusOne( const char *basepath, char *evalpath, int slashcount,size_t nevalpath);
void log_attempt( const char *username );
int nbspace(const char *command);
void lshift( char *line );
int antixploit( const char *abspath, char *token );
void logPrintBadfile (const char * msg);
int removeAllRights (const char * filename, struct stat * s);
int makeUnexecutable (const char * filename, struct stat * s);
int hasSomeRwxRights (struct stat * s);
int isExecutable (struct stat * s);
int symlinkGoesOuttaJail (const char * sl);
void DelBadFiles (const char *basedir);


#endif /* _IBSH_H */
