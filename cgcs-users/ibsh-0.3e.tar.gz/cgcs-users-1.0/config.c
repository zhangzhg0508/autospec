/*
  Created: 03.19.05 11:34:57 by Attila Nagyidai

  $Id: C\040Console.c,v 1.1.2.1 2003/08/13 00:38:46 neum Exp $

  This file is part of IBSH (Iron Bars Shell) , a restricted Unix shell
  Copyright (C) 2005  Attila Nagyidai

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Author: Attila Nagyidai
  Email: na@ent.hu

  Co-Author: Shy
  Email: shy@cpan.org

  Co-Author: Witzy
  Email: stazzz@altern.org
  
  URL: http://ibsh.sourceforge.net
  IRC: irc.freenode.net #ibsh
  RSS, Statistics, etc: http://sourceforge.net/projects/ibsh/

*/

/* Header files */
#include "ibsh.h"

extern Strng commands[MAX_ITEMS];
extern Strng extensions[MAX_ITEMS];

/* Shy's improved version of the original (and not well working) loadconfig. */
/* Reads both config files, and parses the contents into arrays. */
/* This one effectively dismisses every comment from the files. */
/* Technical Description: */
/* Variables: file pointer, counters, temporary string arrays. */
/* The method is the same for both files. First open the file, catch */
/* any errors. Read file 'til eof. Not read comments (starting with '#'), */
/* remove trailing newline character. Copy the finished item to the */
/* pass-by-address arguments. */
int LoadConfig( void )
{
  FILE *fp;
  int i = 0;
  char *file_user;
  
  Strng tmp[MAX_ITEMS];
  Strng tmp2[MAX_ITEMS];

  /* COMMAND CONFIG !!!! */
  file_user = (char *)malloc(strlen(loggedin.uname) + strlen(COMMANDS_DIR) + strlen(".cmds") + 2);

  if(loggedin.uname != NULL)
  	sprintf(file_user, "%s/%s.cmds", COMMANDS_DIR, loggedin.uname);
  else{
	  free(file_user);
	  return -1;
  }

  /* Open global config,if not present go out !!! */
  if((fp = fopen(COMMANDS_FILE,"r")) == NULL) {
      OPENLOG;
      syslog(LOG_ERR, "ibsh panic! Global commands file %s can not be read.", COMMANDS_FILE);
      CLOSELOG;
      exit(0);
  }

  while (!feof(fp) && (i<MAX_ITEMS)) {
        fgets(tmp[i],STRING_SIZE,fp);
        if ( tmp[i][0] != '#' ) {
                /* Delete '\n' */
                tmp[i][strlen(tmp[i]) - 1] = '\0';
                strncpy(commands[i],tmp[i],strlen(tmp[i]));
	
#ifdef DEBUG
                printf("COMMANDS %s\n",commands[i]);
#endif
		i++;
      }
  }
  fclose(fp);


#ifdef DEBUG
  printf("FILE USER %s\n",file_user);
#endif
  /* Add the user command */
  if ((fp = fopen(file_user,"r")) == NULL) {
 	      free(file_user);
	}
  else {
  i--;
  
  while (!feof(fp) && (i<MAX_ITEMS)) {
        fgets(tmp[i],STRING_SIZE,fp);
        if ( tmp[i][0] != '#' ) {
                // Delete '\n'
                tmp[i][strlen(tmp[i]) - 1] = '\0';
                strncpy(commands[i],tmp[i],strlen(tmp[i]));
#ifdef DEBUG
                printf("COMMANDS %s\n",commands[i]);
#endif

		i++;
      }
  }
  fclose(fp);
  free(file_user);
  }

  i = 0;
  
  /* EXTENSIONS CONFIG !!!!*/
  
  file_user = (char *)malloc(strlen(loggedin.uname) + strlen(EXTENSIONS_DIR) + strlen(".xtns") + 2);
  
  sprintf(file_user, "%s/%s.xtns", EXTENSIONS_DIR, loggedin.uname);

    /* Open global config,if not present go out !!! */
  if((fp = fopen(EXTENSIONS_FILE,"r")) == NULL) {
      OPENLOG;
      syslog(LOG_ERR, "ibsh panic! Global extensions file %s can not be read.", EXTENSIONS_FILE);
      CLOSELOG;
      printf("heyxtns");
      exit(0);
  }

  while (!feof(fp) && (i<MAX_ITEMS)) {
    fgets(tmp2[i],STRING_SIZE,fp);
        if ( tmp2[i][0] != '#' ) {
                /* Delete '\n' */
                tmp2[i][strlen(tmp2[i]) - 1] = '\0';
                strncpy(extensions[i],tmp2[i],strlen(tmp2[i]));
#ifdef DEBUG
                printf("EXTENSIONS %s\n",extensions[i]);
#endif
		i++;
      }
  }
  fclose(fp);

  
  /* Add the user extensions */
  if ((fp = fopen(file_user,"r")) == NULL) {
 	      free(file_user);
	      return 0;
	}

  i--;
  
  while (!feof(fp) && (i<MAX_ITEMS)) {
        fgets(tmp2[i],STRING_SIZE,fp);
        if ( tmp2[i][0] != '#' ) {
                // Delete '\n'
                tmp2[i][strlen(tmp2[i]) - 1] = '\0';
                strncpy(extensions[i],tmp2[i],strlen(tmp2[i]));
                printf("EXTENSIONS %s\n",extensions[i]);
		i++;
      }
  }
  fclose(fp);
  free(file_user);
  
  return 0;
}

