#!/usr/bin/env python

"""
Copyright (c) 2014 Wind River Systems, Inc.

SPDX-License-Identifier: Apache-2.0

"""

import setuptools

setuptools.setup(
    name='tsconfig',
    version='1.0.0',
    description='tsconfig',
    license='Apache-2.0',
    packages=['tsconfig'],
    entry_points={}
)
