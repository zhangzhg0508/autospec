/* automatically generated. DO NOT EDIT. */
#include <linux/drbd.h>
const char *drbd_buildtag(void)
{
	return "GIT-hash: 89a294209144b68adb3ee85a73221f964d3ee515"
		" build by phil@fat-tyre, 2013-02-05 15:35:49";
}
