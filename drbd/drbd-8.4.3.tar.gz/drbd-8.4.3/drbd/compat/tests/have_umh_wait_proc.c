#include <linux/kmod.h>

void foo()
{
	int bar = UMH_WAIT_PROC;
}
