#include <linux/net.h>

#ifndef kernel_sock_shutdown
void *p = kernel_sock_shutdown;
#endif
