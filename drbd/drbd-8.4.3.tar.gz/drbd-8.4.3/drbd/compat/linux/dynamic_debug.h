#ifndef _DYNAMIC_DEBUG_H
#define _DYNAMIC_DEBUG_H

#ifndef dynamic_dev_dbg
#define dynamic_dev_dbg(dev, fmt, ...)
#endif

#endif
