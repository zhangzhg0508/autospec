# vim: tabstop=4 shiftwidth=4 softtabstop=4
#
# Copyright (c) 2018 Wind River Systems, Inc.
#
# SPDX-License-Identifier: Apache-2.0
#


def upgrade(migrate_engine):
    pass


def downgrade(migration_engine):
    pass
