# vim: tabstop=4 shiftwidth=4 softtabstop=4
#
# Copyright (c) 2017 Wind River Systems, Inc.
#
# SPDX-License-Identifier: Apache-2.0
#

# Placeholder to allow potential migration patches for 16.10
# TiC Release4 (17.x) starts at version 046_....


def upgrade(migrate_engine):
    pass


def downgrade(migration_engine):
    pass
