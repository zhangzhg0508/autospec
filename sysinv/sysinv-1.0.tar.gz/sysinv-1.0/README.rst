Placeholder to allow setup.py to work.
Removing this requires modifying the
setup.py manifest.
