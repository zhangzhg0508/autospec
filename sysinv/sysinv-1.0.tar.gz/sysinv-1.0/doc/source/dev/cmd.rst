.. _cmd:

==========================
List of Installed Commands
==========================

.. toctree::
    ../api/sysinv.cmd.api
    ../api/sysinv.cmd.dbsync
    ../api/sysinv.cmd.conductor
