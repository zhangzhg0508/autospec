.. _api:

===========
Ironic's API Server
===========

.. toctree::
    ../api/sysinv.api.config
    ../api/sysinv.api.controllers.root
    ../api/sysinv.api.controllers.v1
    ../api/sysinv.api.hooks
