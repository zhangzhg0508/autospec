.. _drivers:

=================
Pluggable Drivers
=================

.. toctree::
    ../api/sysinv.drivers.base
    ../api/sysinv.drivers.fake
    ../api/sysinv.drivers.ipmi
