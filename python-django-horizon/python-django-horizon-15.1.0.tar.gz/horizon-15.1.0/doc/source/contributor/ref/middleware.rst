==================
Horizon Middleware
==================

HorizonMiddleware
-----------------

.. autoclass:: horizon.middleware.HorizonMiddleware
   :members:

OperationLogMiddleware
----------------------

.. autoclass:: horizon.middleware.OperationLogMiddleware
   :members:
