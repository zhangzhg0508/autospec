# Example Test Configs

## Purpose
This folder contains example cloud configs found on
[cloudinit.readthedocs.io](https://cloudinit.readthedocs.io/en/latest/topics/examples.html).
Examples covered by other tests, like modules, are excluded from tests here
to prevent duplication and reduce test time.

## Structure
One test per example test config on cloudinit.readthedocs.io

# vi: ts=4 expandtab
