.. include:: ../../../HACKING.rst
.. vi: textwidth=78
