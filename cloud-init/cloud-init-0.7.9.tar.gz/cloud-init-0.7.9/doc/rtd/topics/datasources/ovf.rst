OVF
===

The OVF Datasource provides a datasource for reading data from
on an `Open Virtualization Format
<https://en.wikipedia.org/wiki/Open_Virtualization_Format>`_ ISO
transport.

For further information see a full working example in cloud-init's
source code tree in doc/sources/ovf

.. vi: textwidth=78
