/*
 * Copyright (c) 2013, 2015 Wind River Systems, Inc.
*
* SPDX-License-Identifier: Apache-2.0
*
 */

 /**
  * @file
  * Wind River CGTS Platform Nodal Health Check Agent Stubs
  */

#include <string.h>

using namespace std;

#include "nodeBase.h"
#include "nodeUtil.h"
