
if [ -f /etc/sysconfig/debug ]; then
    . /etc/sysconfig/debug
fi
