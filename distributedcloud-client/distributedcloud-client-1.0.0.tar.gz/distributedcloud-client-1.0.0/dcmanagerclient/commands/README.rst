===============================
Commands
================================

This module helps in mapping dcmanager commands to APIs.
