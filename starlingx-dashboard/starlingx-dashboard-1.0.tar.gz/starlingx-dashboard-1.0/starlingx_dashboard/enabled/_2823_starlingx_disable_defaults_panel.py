PANEL_DASHBOARD = 'admin'
PANEL_GROUP = 'system'
PANEL = 'defaults'
REMOVE_PANEL = True
