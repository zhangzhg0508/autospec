/**
 * Copyright (c) 2017 Wind River Systems, Inc.
*
* SPDX-License-Identifier: Apache-2.0
*
 */

(function() {
  'use strict';

  describe('horizon.dashboard.dc_admin.cloud_overview', function() {
    it('should exist', function() {
      expect(angular.module('horizon.dashboard.dc_admin.cloud_overview')).toBeDefined();
    });
  });

})();
