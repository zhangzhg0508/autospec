#
# Copyright (c) 2016-2019 Wind River Systems, Inc.
#
# SPDX-License-Identifier: Apache-2.0
#

PREFIX = 'admin/storage_overview/'
STORAGE_OVERVIEW_TEMPLATE_NAME = PREFIX + 'storage_overview.html'
STORAGE_SERVICE_DETAIL_TEMPLATE_NAME = PREFIX + '_detail_storageservices.html'
