:mod:`client` -- HPE3ParClient
===========================================

.. automodule:: hpe3parclient
   :synopsis: HPE 3PAR REST Web client

   .. autodata:: version


Sub-modules:

.. toctree::
   :maxdepth: 2

   client
   exceptions
   file_client
   http
