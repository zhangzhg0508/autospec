API Documentation
=================

The **HPE3PARClient** package contains a :mod:`hpe3parclient` class which extends a more
generic :mod:`http` class for doing REST calls.

.. toctree::
   :maxdepth: 2

   hpe3parclient/index
