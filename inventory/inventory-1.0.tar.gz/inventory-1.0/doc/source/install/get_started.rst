==========================
inventory service overview
==========================
The inventory service provides host inventory of resources on the host.

The inventory service consists of the following components:

``inventory-api`` service
  Accepts and responds to end user API calls...
