=============
Configuration
=============

Configuration of inventory.
