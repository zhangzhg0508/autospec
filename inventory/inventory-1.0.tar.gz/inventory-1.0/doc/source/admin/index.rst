====================
Administrators guide
====================

Administrators guide of inventory.
