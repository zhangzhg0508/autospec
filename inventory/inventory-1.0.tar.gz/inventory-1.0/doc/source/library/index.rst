=====
Usage
=====

To use inventory in a project:

    import inventory
