#ifndef __INCLUDE_HWMONMODEL_H__
#define __INCLUDE_HWMONMODEL_H__

/*
 * Copyright (c) 2017 Wind River Systems, Inc.
*
* SPDX-License-Identifier: Apache-2.0
*
 */

 /**
  * @file
  * Wind River Titanium Cloud's Hardware Monitor "Sensor Model" Header
  */

#endif
