#ifndef _HOSTW_MSG_H
#define _HOSTW_MSG_H

/*
 * Copyright (c) 2015 Wind River Systems, Inc.
*
* SPDX-License-Identifier: Apache-2.0
*
 */

/* Note that using Unix abstract namespace, this will be prepended by a
 * NULL character
 */
#define HOSTW_UNIX_SOCKNAME "HostWatchdog"

#endif /* _HOSTW_MSG_H */

