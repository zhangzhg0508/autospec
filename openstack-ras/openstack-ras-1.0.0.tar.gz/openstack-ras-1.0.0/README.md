openstack-resource-agents
=========================

Pacemaker High Availability resource agents for OpenStack