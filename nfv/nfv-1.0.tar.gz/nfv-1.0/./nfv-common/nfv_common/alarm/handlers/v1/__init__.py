#
# Copyright (c) 2015-2016 Wind River Systems, Inc.
#
# SPDX-License-Identifier: Apache-2.0
#
from nfv_common.alarm.handlers.v1._alarm_handler import AlarmHandler  # noqa: F401
