#
# Copyright (c) 2015-2016 Wind River Systems, Inc.
#
# SPDX-License-Identifier: Apache-2.0
#
from nfv_common.catalog.model._defs import CONNECTION_TYPE  # noqa: F401
from nfv_common.catalog.model._defs import CONNECTIVITY_TYPE  # noqa: F401
from nfv_common.catalog.model._vnf_descriptor import ConnectionPointVNFC  # noqa: F401
from nfv_common.catalog.model._vnf_descriptor import ConnectionPointVNFD  # noqa: F401
from nfv_common.catalog.model._vnf_descriptor import ConstituentVDU  # noqa: F401
from nfv_common.catalog.model._vnf_descriptor import DeploymentFlavor  # noqa: F401
from nfv_common.catalog.model._vnf_descriptor import VDU  # noqa: F401
from nfv_common.catalog.model._vnf_descriptor import VirtualLink  # noqa: F401
from nfv_common.catalog.model._vnf_descriptor import VNFC  # noqa: F401
from nfv_common.catalog.model._vnf_descriptor import VNFD  # noqa: F401
