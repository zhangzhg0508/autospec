#
# Copyright (c) 2015-2016 Wind River Systems, Inc.
#
# SPDX-License-Identifier: Apache-2.0
#
from nfv_vim.api.controllers.v1.openstack._controller import OpenStackAPI  # noqa: F401
