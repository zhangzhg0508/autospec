#
# Copyright (c) 2015-2016 Wind River Systems, Inc.
#
# SPDX-License-Identifier: Apache-2.0
#
from nfv_vim.api.controllers.v1.orchestration.sw_update._sw_patch import SwPatchAPI  # noqa: F401
from nfv_vim.api.controllers.v1.orchestration.sw_update._sw_upgrade import SwUpgradeAPI  # noqa: F401
