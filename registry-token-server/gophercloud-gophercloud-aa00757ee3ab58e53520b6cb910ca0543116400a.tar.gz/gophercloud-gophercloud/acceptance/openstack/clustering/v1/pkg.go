// Package v1 package contains acceptance tests for the Openstack Clustering V1 service.
package v1
