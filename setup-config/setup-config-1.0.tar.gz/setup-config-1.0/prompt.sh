if [ "$PS1" ]; then
    PS1='\h:\w\$ '
fi
export PS1
