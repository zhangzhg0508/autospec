RBD Provisioner Chart
-------------------------------------------------------------------------------
This chart was last validated with:
* Repo: https://github.com/kubernetes-incubator/external-storage.git
* Commit: (6776bba1) Merge pull request #1048 from AdamDang/patch-3
