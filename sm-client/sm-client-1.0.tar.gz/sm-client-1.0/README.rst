Python bindings for the Service Management API
==============================================

A python and command line client library for Service Management.

