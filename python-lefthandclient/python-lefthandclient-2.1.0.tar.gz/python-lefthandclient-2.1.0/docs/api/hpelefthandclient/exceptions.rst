:mod:`exceptions` -- HTTP Exceptions
====================================================

.. automodule:: hpelefthandclient.exceptions
   :synopsis: HTTP Exceptions

   .. autoclass:: hpelefthandclient.exceptions.HTTPNotFound
   .. autoclass:: hpelefthandclient.exceptions.HTTPBadRequest
