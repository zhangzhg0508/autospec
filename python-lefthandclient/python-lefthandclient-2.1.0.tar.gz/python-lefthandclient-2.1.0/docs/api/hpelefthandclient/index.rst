:mod:`client` -- HPELeftHandClient
==================================

.. automodule:: hpelefthandclient
   :synopsis: HPE LeftHand REST Web client

   .. autodata:: version


Sub-modules:

.. toctree::
   :maxdepth: 2

   client
   exceptions
   http

