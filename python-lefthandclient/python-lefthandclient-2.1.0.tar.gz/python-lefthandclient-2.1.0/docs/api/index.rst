API Documentation
=================

The HPE LeftHand Client package contains a :mod:`hpelefthandclient` class which extends a more
generic :mod:`http` class for doing REST calls

.. toctree::
   :maxdepth: 2

   hpelefthandclient/index

