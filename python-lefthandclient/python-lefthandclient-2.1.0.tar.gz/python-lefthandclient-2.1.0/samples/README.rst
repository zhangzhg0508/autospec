This directory is going away.....
The unit tests are in 'test'

This directory contains unit tests

flask_server.py -- is a sample server that acts like a LeftHand OS API server.   
  This requires python-flask

How to run the tests
* First run the api server
  python flask_server.py

* Now run the test client.
  python test_client.py



for overriding error content in flask
http://flask.pocoo.org/snippets/83/
http://flask.pocoo.org/docs/api/?highlight=abort#flask.Flask.errorhandler
