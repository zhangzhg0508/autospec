===============================
OpenStack Drivers
================================

Driver for openstack communication based on python native clients.
