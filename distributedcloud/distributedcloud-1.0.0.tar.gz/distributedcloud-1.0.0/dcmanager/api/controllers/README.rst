===============================
controllers
===============================

API request processing

root.py:
    API root request

subclouds.py
    Controller for all the subcloud related requests

restcomm.py:
    common functionality used in API
