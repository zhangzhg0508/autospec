===============================
cmd
===============================

Scripts to start the DC dbsync API service

api.py:
    start API service
    python api.py --config-file=/etc/dcdbsync/dcdbsync.conf
