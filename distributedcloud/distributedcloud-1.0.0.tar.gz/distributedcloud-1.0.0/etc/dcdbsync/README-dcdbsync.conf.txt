To generate the sample dcdbsync.conf file, run the following
command from the top level of the dcdbsync directory:

tox -egenconfig
