To generate the sample dcorch.conf file, run the following
command from the top level of the dcorch directory:

tox -egenconfig
