To generate the sample dcmanager.conf file, run the following
command from the top level of the dcmanager directory:

tox -egenconfig
