===============================
snmp
===============================

DC Orchestrator SNMP is an SNMP Trap reciver service to handle alarm events
generated in the subclouds. Alarms are throttled and sent by rpc to the 
orchestrator engine to update the alarm summary of the subcloud


