DistributedCloud
===============================

Wind River's Distributed Cloud system supports an edge computing solution by providing
central management and orchestration for a geographically distributed network of Titanium
Cloud systems.
